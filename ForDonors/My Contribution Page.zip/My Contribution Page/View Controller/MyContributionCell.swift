//
//  MyContributionCell.swift
//  ForDonors
//
//  Created by NITS_Mac3 on 19/06/18.
//  Copyright © 2018 NATIT. All rights reserved.
//

import UIKit

class MyContributionCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
